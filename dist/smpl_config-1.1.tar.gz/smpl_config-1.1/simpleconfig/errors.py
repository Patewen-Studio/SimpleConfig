
class ParseException(Exception):
    pass
