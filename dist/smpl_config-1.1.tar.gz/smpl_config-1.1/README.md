# SimpleConfig - easy to parse config!

### How to install? 
```bash
$ pip install smpl_config
```
