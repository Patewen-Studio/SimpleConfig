from setuptools import setup

setup(name='smpl_config',
      version='1.1b1',
      description='SimpleConfig module',
      packages=['simpleconfig'],
      author_email='elezor.2009@gmail.com',
      zip_safe=False)